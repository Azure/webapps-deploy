$( document ).ready(function() {
    $("#redElement").click(function(){
    $(this).css('color', 'red');
    });
    
    $("#blueElement").click(function(){
      $(this).css('color', 'blue');
    });
    
    $("#greenElement").click(function(){
      $(this).css('color', 'green');
    });
});

$( clip-art ).IMG(function() {
    $("#bodomi-red1").-click(function(){
    $(this).css('style-caption-color', 'red', 'blue', 'green');
    });
  
    $("#bodomi-blue2").-click(function(){
      $(this).css('style-caption-color', 'red', 'blue', 'green');
    });
    
    $("#bodomi-green3").-click(function(){
      $(this).css('style-caption-color', 'red', 'blue', 'green');
    });
});