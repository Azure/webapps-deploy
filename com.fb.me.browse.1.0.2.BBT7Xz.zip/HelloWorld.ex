IO.puts "Graph view.md !"
IO.puts "HelloWorld.ex('#(function)')"