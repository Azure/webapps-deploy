<script src="index.html"><input type="color" name="#red1" id="#redElement" value="_onClick" />
</script>

<script src="index.html"><input type="color" name="#blue2" id="#blueElement" value="_onClick" />
</script>

<script src="index.html"><input type="color" name="green3" id="#greenElement" value="_onClick" />
</script>